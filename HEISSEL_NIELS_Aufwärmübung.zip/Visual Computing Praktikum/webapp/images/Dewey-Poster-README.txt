https://en.wikipedia.org/wiki/File:Dewey_Decimal_System_Poster.jpg

Source: 	Flickr: Dewey Decimal System Poster
Author: 	Maggie Appleton

This image, which was originally posted to Flickr.com, was uploaded to Commons using Flickr upload bot on 23:09, 16 November 2013 (UTC) by SPat (talk). On that date it was licensed under the license below.

This file is licensed under the Creative Commons Attribution-Share Alike 2.0 Generic license.