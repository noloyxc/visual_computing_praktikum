The Adobe PDF icon is taken from Adobe's home under the permission rights specified there:

http://www.adobe.com/legal/permissions/icons-web-logos.html