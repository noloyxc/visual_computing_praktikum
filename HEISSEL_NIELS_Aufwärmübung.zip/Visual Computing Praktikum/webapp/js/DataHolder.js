!function () {
    var DataHolder = {};
    var jsonData;
    var xmlData;
    var xmlText;
    var thisDocuments;
    function initTestInput(file) {
//        if (window.XMLHttpRequest)
//        {// code for IE7+, Firefox, Chrome, Opera, Safari
//            xmlhttp = new XMLHttpRequest();
//        } else
//        {// code for IE6, IE5
//            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
//        }
//        xmlhttp.open("GET", file, false);
//        xmlhttp.send();
        
        xmlData =  $.parseXML(fingerdaten);
//        xmlText = xmlhttp.responseText;
        var x2js = new X2JS();
        jsonData = x2js.xml2json(xmlData);
    }

    /**
     * Setzt DemoFile, um TextImager mit Beispieldaten zu füllen.
     * @param {type} filepath   -   Pfad zur Beispieldatei.
     */
    DataHolder.setTestFile = function (filepath) {
        initTestInput(filepath);
    };
//    DataHolder.setTestFile("tolgaoutput.xml");

    /**
     * Falls index eingegeben:
     *      Gibt alle Daten, die in diesem Dokument enthalten sind, aus.
     * Sonst:
     *      Gibt alle Daten, die vorhanden sind, aus.
     * @param {type} index  -   index des Dokuments, von dem die Daten verlangt werden. Leer, falls alle Daten von allen Dokumenten verlangt werden.
     * @returns Alle Daten vom Dokument i = index. Alle Daten falls index leer.
     */
    DataHolder.getDocument = function (index) {
        if (thisDocuments === undefined) {
            DataHolder.groupEntitys();
            DataHolder.groupPOS();
            DataHolder.groupDependency();
            DataHolder.groupConstituents();

            var documents = [].concat(jsonData.XMI.DocElement);
            for (var i in documents) {
                documents[i].text = DataHolder.getString(documents[i]);
            }
            function getDoc(begin, end) {
                return documents.filter(function (e) {
                    return (begin >= parseInt(e._begin) && end <= parseInt(e._end));
                })[0];
            }
            for (var i in jsonData.XMI) {

                var typ = [].concat(jsonData.XMI[i]);
                for (var j in typ) {
                    if (typ[j] instanceof Object) {
                        if (typ[j]._begin && typ[j]._end && "0" !== typ[j]._end) {
                            try {
                                if (!(typ[j]._tagName in getDoc(typ[j]._begin, typ[j]._end)))
                                    getDoc(typ[j]._begin, typ[j]._end)[typ[j]._tagName] = [];
                                getDoc(typ[j]._begin, typ[j]._end)[typ[j]._tagName].push(typ[j]);
                            } catch (e) {
                            }
                        }
                    }
                }
            }
            thisDocuments = documents;
        }
        if (index === undefined)
            return thisDocuments;
        else
            return thisDocuments[index];
    };
    function sortFunction(a, b) {
        return parseInt(a._end) - parseInt(b._end);
    }

    /**
     * Gibt die Ähnlichkeiten zwischen den Elementen in array1 und array2 aus.
     * @param {type} array1 -   Array aus Sätzen
     * @param {type} array2 -   Array aus Sätzen
     * @returns {Array}     -   Gibt die Ähnlichkeiten zwischen allen Elementen aus array1 zu allen Elementen aus array2 zurück.
     */
    DataHolder.getSimilaritys = function (array1, array2) {
        array1 = [].concat(array1);
        array2 = [].concat(array2);
        array1.sort(sortFunction);
        array2.sort(sortFunction);
        var lines = jsonData.XMI.Similarity._value.split(";");
        var elements = lines[0].split(",");
        var data = [];
        for (var i = 1; i < lines.length - 1; i++) {
            data[i - 1] = lines[i].split(",");
        }

        var output = [];
        for (var i in array1) {
            var indesElement1 = elements.indexOf(array1[i]._begin + "-" + array1[i]._end);
            array1[i].index = i;
            for (var j in array2) {
                var indesElement2 = elements.indexOf(array2[j]._begin + "-" + array2[j]._end);
                if (indesElement1 !== indesElement2 && indesElement2 - indesElement1 - 1 >= 0) {
                    array2[j].index = j;
                    output.push(
                            {
                                element1: array1[i],
                                element2: array2[j],
                                score: data[indesElement1][indesElement2 - indesElement1 - 1]
                            });
                }
            }
        }
//        console.log(output);
        return output;
    };

    /**
     * Berechnet den Konstituentenbaum aus den Daten.
     * @param {type} docIndex   -   Index vom Dokument
     * @param {type} sentenceIndex  -   Index vom Satz aus dem Dokument.
     * @returns Json Graph, der den Konstituentenbaum repräsentiert.
     */
    DataHolder.getConstitiuentStructure = function (docIndex, sentenceIndex) {
        var constituents = DataHolder.getDocStructure(docIndex, ["Sentence", "Constituent"])[sentenceIndex].Constituent;
        var tokens = DataHolder.getDocStructure(docIndex, ["Sentence", "Token"])[sentenceIndex].Token;
        var combi = tokens.concat(constituents);
        var map = [];
        var rootId;
        for (var i in constituents) {
            var childrens = constituents[i]._children.split(" ");
            for (var j in childrens) {
                if (map[constituents[i]["_xmi:id"]]) {
                    map[constituents[i]["_xmi:id"]].push(childrens[j])
                }
                else {
                    map[constituents[i]["_xmi:id"]] = [childrens[j]];
                }
            }
            if (constituents[i]._value === "ROOT")
                rootId = constituents[i]["_xmi:id"];
        }
        var root = constituents.filter(function (el) {
            return el["_xmi:id"] === rootId;
        })[0];
        var output = {
            begin: root._begin,
            end: root._end,
            id: root["_xmi:id"],
            children: getChildren(root),
            name: root._constituentType
        };
        function getChildren(node) {

            var constituentChilds = combi.filter(function (el) {
                return ($.inArray(el["_xmi:id"], map[node["_xmi:id"]]) >= 0);
            });
            var output = [];
            if (constituentChilds.length > 0)
                for (var i in constituentChilds) {
                    if (!(typeof constituentChilds[i] == "function")) {
                        if (constituentChilds[i]._constituentType) {
                            var tmp = {
                                begin: constituentChilds[i]._begin,
                                end: constituentChilds[i]._end,
                                id: constituentChilds[i]["_xmi:id"],
                                typ: "",
                                name: constituentChilds[i]._constituentType
                            };
                            var c = getChildren(constituentChilds[i]);
                            if (c.length > 0)
                                tmp.children = c;
                            output.push(tmp);
                        }
                        else {
                            var tmp = {
                                begin: constituentChilds[i]._begin,
                                end: constituentChilds[i]._end,
                                id: constituentChilds[i]["_xmi:id"],
                                typ: "",
                                name: DataHolder.getString(constituentChilds[i])
                            };
                            output.push(tmp);
                        }
                    }
                }
            output.sort(function (a, b) {
                return a.begin - b.begin
            });

            return output;
        }
        return output;
    };

    /**
     * Berechnet den Dependenzbaum aus den Daten.
     * @param {type} docIndex   -   Index vom Dokument
     * @param {type} sentenceIndex  -   Index vom Satz aus dem Dokument.
     * @returns Json Graph, der den Dependenzbaum repräsentiert.
     */
    DataHolder.getDependencyStructure = function (docIndex, sentenceIndex) {
        var Sentence = DataHolder.getDocStructure(docIndex, ["Sentence", "Token", "Dependency"])[sentenceIndex];
        var tokens = Sentence.Token;
        var map = [];
        var allDependencyIds = [];
        for (var i in tokens) {
            if (tokens[i].Dependency) {
                allDependencyIds[tokens[i].Dependency[0]._Governor] = true;
                allDependencyIds[tokens[i].Dependency[0]._Dependent] = true;
                if (map[tokens[i].Dependency[0]._Governor]) {
                    map[tokens[i].Dependency[0]._Governor].push(tokens[i].Dependency[0]._Dependent)
                }
                else {
                    map[tokens[i].Dependency[0]._Governor] = [tokens[i].Dependency[0]._Dependent];
                }
            }
        }
        for (var i in map) {
            for (var j in map[i]) {
                if (allDependencyIds[map[i][j]]) {
                    allDependencyIds[map[i][j]] = false;
                }
            }
        }
        var rootId;
        for (var i in allDependencyIds) {
            if (allDependencyIds[i])
                rootId = i;
        }
        var root = tokens.filter(function (el) {
            return el["_xmi:id"] === rootId;
        })[0];
        var output = {
            begin: root._begin,
            end: root._end,
            id: root["_xmi:id"],
            children: getChildren(root),
            name: DataHolder.getString(root)
        };
        function getChildren(token) {
            var childs = tokens.filter(function (el) {
                return el.Dependency && el.Dependency[0]._Governor === token["_xmi:id"];
            });
            var output = [];
            if (childs.length > 0)
                for (var i in childs) {
                    if (!(typeof childs[i] == "function")) {
                        var tmp = {
                            begin: childs[i]._begin,
                            end: childs[i]._end,
                            id: childs[i]["_xmi:id"],
                            typ: childs[i].Dependency[0]._DependencyType,
                            name: DataHolder.getString(childs[i])
                        };
                        var c = getChildren(childs[i]);
                        if (c.length > 0)
                            tmp.children = c;
                        output.push(tmp);
                    }
                }
            return output;
        }
        return output;
    };

    /**
     * Gibt den String von einem Element aus.
     * @param {type} element    -   Element, von dem der String zu bestimmen ist
     * @returns Stringvalue von element.
     */
    DataHolder.getString = function (element) {
        return jsonData.XMI.Sofa._sofaString.substring(element._begin, element._end);
    }

    /**
     * Gibt verschachtelte Daten wieder.
     * @param {type} documentIndex  -   Index vom Dokumenten, um welches es sich handelt.
     * @param {type} structure  -   Beispiel: ["Sentence", "Location"]
     * @returns Gibt die verschachtelte Struktur zurück. In dem Beispiel oben, würden alle erkannten Locations, den jeweiligen Sätzen in denen sie vorkommen, zugeordnet.
     */
    DataHolder.getDocStructure = function (documentIndex, structure) {
        structure.reverse();
        var document = DataHolder.getDocument(documentIndex);
        var output = document[structure[0]];
        for (var i = 1; i < structure.length; i++) {
            if (document[structure[i]] !== undefined)
                output = DataHolder.selectCovered(document[structure[i]], output);
        }
        return output;
    };

    /**
     * Gibt den HTML String, der in dem Dokument-Panel ausgegeben werden soll.
     * @param {type} documentIndex
     * @param {type} structure
     * @returns {String}
     */
    DataHolder.getHTML = function (documentIndex, structure) {
        var document = DataHolder.getDocument(documentIndex);
        var textWithPointer = createTextWithPointer(document.text);
        var offset = parseInt(document._begin);
        for (var i in structure) {
            for (var j in document[structure[i]]) {
                addAnnotation(document[structure[i]][j], textWithPointer);
            }
        }

        function createTextWithPointer(input) {
            var start = {char: input[0], pointer: null};
            var current = start;
            for (var index = 1; index < input.length; ++index) {
                current.pointer = {char: input[index], pointer: null};
                current = current.pointer;
            }
            return start;
        }

        function addAnnotation(nlpClass, text) {
            addOpen(nlpClass, text);
            addClose(nlpClass, text);
        }

        function addOpen(nlpClass, text) {
            var current = getElement(parseInt(nlpClass._begin - offset), text);
            if (current.open === undefined)
                current.open = [];
            current.open.push(nlpClass);
        }

        function addClose(nlpClass, text) {
            var current = getElement(parseInt(nlpClass._end - offset) - 1, text);
            if (current.close === undefined)
                current.close = [];
            current.close.unshift(nlpClass);
        }

        function getElement(index, startElement) {
            var current = startElement;
            for (var i = 0; i < index; i++) {
                current = current.pointer;
            }
            return current;
        }

        var current = textWithPointer;
        var output = "";
        while (current !== null) {
            if (current.open !== undefined) {
                for (var i = 0; i < current.open.length; i++) {
//                    console.log(current.open[i]);
                    if (current.open[i]._tagName === "Entity")
                        output += "<span class=\"" + current.open[i]._tagName + " " + current.open[i]["_value"] + "\" id=\"nlp" + current.open[i]["_xmi:id"] + "\"\>";
                    else {
                        if (current.open[i]._tagName === "Language")
                            output += "<span class=\"" + current.open[i]._tagName + " " + current.open[i]["_language"] + "\" id=\"nlp" + current.open[i]["_xmi:id"] + "\"\>";
                        else {
                            if (current.open[i]._tagName === "PartOfSpeech")
                                output += "<span class=\"" + current.open[i]._tagName + " " + current.open[i]["_PosValue"].replace("$", "/") + "\" id=\"nlp" + current.open[i]["_xmi:id"] + "\"\>";
                            else
                                output += "<span class=\"" + current.open[i]._tagName + "\" id=\"nlp" + current.open[i]["_xmi:id"] + "\"\>";
                        }
                    }
                }
                console.log();
            }
            output += current.char;
            if (current.close !== undefined) {
                for (var i = 0; i < current.close.length; i++) {
                    output += "</span>";
                }
            }
            current = current.pointer;
        }
        return output;
    };

    /**
     * Setzt alle childObjects in die zugehörigen parentObjects
     * @param {type} parentObjects  -   Objects, in die die childObjects hinzugefügt werden sollen
     * @param {type} childObjects   -   Objects, die in die parentObjects einteilt werden sollen
     * @returns Json mit den parentObjects und zusätzlich den untergeordneten childObjects.
     */
    DataHolder.selectCovered = function (parentObjects, childObjects) {
        parentObjects = [].concat(parentObjects);
        childObjects = [].concat(childObjects);
        parentObjects.sort(sortFunction);
        childObjects.sort(sortFunction);
        for (var i in childObjects) {
            if (!(typeof childObjects[i] === "function")) {
                var foundParent = parentObjects.filter(function (e) {
                    if (parseInt(e._begin) <= parseInt(childObjects[i]._begin) && parseInt(e._end) >= parseInt(childObjects[i]._end)) {
//                        console.log(parseInt(e._begin) + " <= " + parseInt(childObjects[i]._begin));
//                        console.log(parseInt(e._end) + " >= " + parseInt(childObjects[i]._end));
                        return true;
                    }
                    else
                        return false
//                    return parseInt(e._begin) <= parseInt(childObjects[i]._begin), parseInt(e._end) >= parseInt(childObjects[i]._end);
                })[0];
//                console.log(foundParent);
                if (foundParent) {
                    if (!(childObjects[i]._tagName in foundParent))
                        foundParent[childObjects[i]._tagName] = [];
                    var alreadyExists = foundParent[childObjects[i]._tagName].some(function (e) {
                        return e["_xmi:id"] === childObjects[i]["_xmi:id"];
                    });
                    if (!alreadyExists) {
                        foundParent[childObjects[i]._tagName].push(childObjects[i]);
                    }
                }
            }
        }
        return parentObjects;
    };

    /**
     * Filtert die childObjects, die in den parentObjects vorkommen
     * @param {type} parentObjects  -   Objekte, die das Filterkriterium sind.
     * @param {type} childObjects   -   Objekte, die gefiltert werden sollen
     * @returns Eine Teilmenge von childObjects. Diejenigen, die in parentObjects vorkommen.
     */
    DataHolder.filterCovered = function (parentObjects, childObjects) {
        parentObjects = [].concat(parentObjects);
        childObjects = [].concat(childObjects);
        parentObjects.sort(sortFunction);
        childObjects.sort(sortFunction);
        var filteredChildren = childObjects.filter(function (e) {
            for (var i in parentObjects) {
                if (!(typeof parentObjects[i] === "function"))
                    if (parseInt(parentObjects[i]._begin) <= parseInt(e._begin) && parseInt(parentObjects[i]._end) >= parseInt(e._end))
                        return true;
            }
            return false;
        });
        return filteredChildren;
    };

    DataHolder.getXML = function () {
        return xmlData;
    };

    DataHolder.getText = function () {
        return xmlText;
    };

    DataHolder.setXML = function (input) {
        console.log(input);
        xmlData = $.parseXML(input);
        var x2js = new X2JS();
        jsonData = x2js.xml2json(DataHolder.getXML());
    };

    /**
     * Groupiert alle Entity wie z.B. Location, Person, Organization
     */
    DataHolder.groupEntitys = function () {
        var entitys = [];
        var entitysToCluster = ["Person", "Location", "Organization", "NamedEntity"];
        for (var i in entitysToCluster) {
            if (jsonData.XMI[entitysToCluster[i]]) {
                var tmpEntity = [].concat(jsonData.XMI[entitysToCluster[i]]);
                for (var j = 0; j < tmpEntity.length; j++) {
                    var tmp = tmpEntity[j];
                    tmp["_entityValue"] = tmp["_value"];
                    tmp["_value"] = tmp["_tagName"];
                    tmp["_tagName"] = "Entity";
                }
            }
        }
    };

    /**
     * Groupiert alle Part of Speeches, wie z.B. PP, NNVP, etc.
     */
    DataHolder.groupPOS = function () {
        var pos = [];
        var posToCluster = [];
        for (var i in jsonData.XMI) {
            var tmpData = ([].concat(jsonData.XMI[i]));
            for (var j in tmpData) {
                if (tmpData[j]["__prefix"])
                    if (tmpData[j]["__prefix"] === "pos") {
                        posToCluster.push(tmpData[j]["_tagName"]);
                        break;
                    }
            }
        }
        for (var i in posToCluster) {
            if (jsonData.XMI[posToCluster[i]]) {
                var tmpPOS = [].concat(jsonData.XMI[posToCluster[i]]);
                for (var j = 0; j < tmpPOS.length; j++) {
                    var tmp = tmpPOS[j];
                    if (tmp["__prefix"] === "pos") {
                        tmp["_value"] = tmp["_tagName"];
                        tmp["_tagName"] = "PartOfSpeech";
                    }
                }
            }
        }
    };

    /**
     * Groupiert alle Dependencys
     */
    DataHolder.groupDependency = function () {
        var dependency = [];
        var dependencyToCluster = [];
        for (var i in jsonData.XMI) {
            var tmpData = ([].concat(jsonData.XMI[i]));
            for (var j in tmpData) {
                if (tmpData[j]["__prefix"])
                    if (tmpData[j]["__prefix"] === "dependency") {
                        dependencyToCluster.push(tmpData[j]["_tagName"]);
                        break;
                    }
            }
        }
        for (var i in dependencyToCluster) {
            if (jsonData.XMI[dependencyToCluster[i]]) {
                var tmpPOS = [].concat(jsonData.XMI[dependencyToCluster[i]]);
                for (var j = 0; j < tmpPOS.length; j++) {
                    var tmp = tmpPOS[j];
                    if (tmp["__prefix"] === "dependency") {
                        tmp["_value"] = tmp["_tagName"];
                        tmp["_tagName"] = "Dependency";
                    }
                }
            }
        }
    };

    /**
     * Groupiert alle Konstituenten
     */
    DataHolder.groupConstituents = function () {
        var constituents = [];
        var constituentsToCluster = [];
        for (var i in jsonData.XMI) {
            var tmpData = ([].concat(jsonData.XMI[i]));
            for (var j in tmpData) {
                if (tmpData[j]["__prefix"])
                    if (tmpData[j]["__prefix"] === "constituent") {
                        constituentsToCluster.push(tmpData[j]["_tagName"]);
                        break;
                    }
            }
        }
        for (var i in constituentsToCluster) {
            if (jsonData.XMI[constituentsToCluster[i]]) {
                var tmpPOS = [].concat(jsonData.XMI[constituentsToCluster[i]]);
                for (var j = 0; j < tmpPOS.length; j++) {
                    var tmp = tmpPOS[j];
                    if (tmp["__prefix"] === "constituent") {
                        tmp["_value"] = tmp["_tagName"];
                        tmp["_tagName"] = "Constituent";
                    }
                }
            }
        }
    };

    /**
     * Gibt die Json mit allen vorhandenen Daten wieder.
     * @returns Json mit allen Daten
     */
    DataHolder.getJson = function () {
        return jsonData;
    };

    /**
     * Berechnet die Vater-Sohn-Struktur mithilfe des childAttributes
     * @param {type} elements   -   Das Hauptelement von dem die Struktur bestimmt werden soll.
     * @param {type} childAttribute     -   Das Attribut, dass die Struktur angibt.
     * @returns Json mit children, size und leaf.
     */
    DataHolder.getChildParentStructure = function (elements, childAttribute) {
        function getRootId() {
            return elements.filter(function (e) {
                return e._isRoot === "true";
            })[0]["_xmi:id"];
        }

        var rootId = getRootId();
        var rootElement = DataHolder.getElementFromList(rootId, elements);
        function buildPath(json, e) {
            json.id = e["_xmi:id"];
            if (e[childAttribute] !== null) {
                json.name = e["_value"];
                var children = e[childAttribute].split(" ");
                if (DataHolder.getElementFromList(children[0], elements)._tagName === rootElement._tagName) {
                    json.children = [];
                    for (var i in children) {
                        json.children[i] = buildPath({}, DataHolder.getElementFromList(children[i], elements));
                    }
                } else {
                    json.size = children.length;
                    json.leafs = children;
                }
            }
            return json;
        }
        return buildPath({}, rootElement);
    };

    DataHolder.getElementFromList = function (id, list) {
        return list.filter(function (el) {
            return id === el["_xmi:id"];
        })[0];
    };

    /**
     * Bestimmt ein Element durch eine Id
     * @param {type} id -   id, mithilfe dessen ein Element gefunden werden soll.
     * @returns Das zugehörige Element.
     */
    DataHolder.getElementById = function (id) {
        return DataHolder.getXML().querySelectorAll('[*|id ="' + id + '"]');
    };

    /**
     * Gibt alle Elemente, mit der zugehörigen id und der annotation aus
     * @param {type} annotation -   Annotationsfilter
     * @param {type} ids        -   id der Elemente die gefunden werden sollen.
     * @returns Array mit allen Elementen, die zu der Annotation gehören und in den ids vertreten sind.
     */
    DataHolder.getElementsByIds = function (annotation, ids) {
        var checkArray = [];
        for (var i in ids) {
            var index = parseInt(ids[i].replace("#nlp", ""));
            checkArray[index] = true;
        }

        var allElements = DataHolder.getXML().querySelectorAll(annotation);
        var elements = [];

        var j = 0;
        for (var i = 0; i < allElements.length; i++) {
            var element = allElements[i];
            var index = parseInt(element.getAttribute("xmi:id"));
            if (checkArray[index] === true) {
                elements.push(element);
                if (++j === ids.length) {
                    break;
                }
            }
        }
        return elements;
    };

    DataHolder.getElementFromListByOffset = function (begin, end, list) {
        return list.filter(function (el) {
            return begin === el["_begin"] && end === el["_end"];
        })[0];
    };
    this.DataHolder = DataHolder;
}();