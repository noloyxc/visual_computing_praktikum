Ext.define('D2Cat.controller.Classification', {
    extend: 'Ext.app.Controller',
    requires: [
    ],
    // Create getter for Components we need
    refs: [
        {ref: 'qsInputText', selector: 'quickstart textfield[name=inputText]'},
        {ref: 'lingunetInputText', selector: 'lingunet textfield[name=lingunetinputText]'},
        {ref: 'lingunet', selector: 'lingunet'},
        {ref: 'inputText', selector: 'inputselection textarea[name=inputText]'},
        {ref: 'outputClassificationXml', selector: 'd2catonline textarea[name=classificationxml]'},
        {ref: 'groupTabPanel', selector: 'grouptabpanel'},
        {ref: 'd2Catonline', selector: 'd2catonline'},
        {ref: 'classificationTree', selector: 'd2catonline classificationtree'},
        {ref: 'propertyFrequencyChart', selector: 'd2catonline propertyfrequencychart'},
        {ref: 'fileuploadField', selector: 'quickstart fileuploadfield'},
        {ref: 'submitForm', selector: 'quickstart form'},
        {ref: 'options', selector: 'optionspanel'}
    ],
    initComponent: function () {
        thatClassification = this;
    },
    init: function () {
        thatClassification = this;

        // Add Listeners to components
        thatClassification.featureLimit;
//        thatClassification.lMonitor = new D2Cat.view.ClassificationProgressWindow();
//	                	  var wsUri = "ws://service.hucompute.org:8080/TextImagerWebsocket/echo";
//	                	  var wsUri = "ws://141.2.108.224:8080/TextImagerWebsocket/echo";
//	                	  websocket = new WebSocket(wsUri);
//	                	  websocket.onopen = function (ws) {
//	                	  console.log('The websocket is ready to use');
//	                	  };
//	                	  websocket.onmessage = function (message) {
//	                	  console.log(message);
//	                	  var output = JSON.parse(message.data);
//	                	  if (output.command === "progress")
//	                	  thatClassification.lMonitor.updateStatus(output.payload);
//	                	  else if (output.command === "result")
//	                	  thatClassification.onClassificationSuccess(output.payload);
//	                	  else if (output.command === "updateLangProc") {
//	                	  console.log(output.payload);
//	                	  thatNewLanguage.change(output.payload);
//	                	  }
//	                	  else
//	                	  console.log(message);
//	                	  };

        thatClassification.lingunetParameters = {cmd: 'analyze'};
        thatClassification.classifierParameters = {cmd: 'classify', nodeLimit: '50', classifier: '1', language: 'Autodetect', lexicon: 'collexen', useHistoricalNames: false, useAnthroponyms: true, useNamedEntities: true};
        thatClassification.inputTextChangeInProgress = false;
        thatClassification.classifierParamComboOpened = false;

        thatClassification.control(
                {
                    'quickstart button[action=texteditor]': {
                        click: thatClassification.openTextEditor
                    },
                    'quickstart button[action=classify]': {
                        click: thatClassification.classify
                    },
                    'quickstart button[action=getdata]': {
                        click: thatClassification.getdata
                    },
                    'quickstart button[action=classifyfile]': {
                        click: thatClassification.classifyFile
                    },
                    'lingunet button[action=analyze]': {
                        click: thatClassification.analyze
                    },
                    'quickstart fileuploadfield': {
                        change: thatClassification.classifyFile
                    },
                    'inputselection textarea': {
                        change: thatClassification.textareaChanged
                    },
                    'quickstart textfield': {
                        specialkey: thatClassification.qsTextfieldEnter,
                        change: thatClassification.qsTextfieldChanged
                    },
                    'lingunet textfield[name=lingunetinputText]': {
                        change: thatClassification.lingunetTextfieldChanged
                    },
                    'd2catonline button[action=downloadtei]': {
                        click: thatClassification.downloadTEI
                    },
                    'lingunet numberfield[name=linguLimit]': {
                        change: thatClassification.linguLimitChanged
                    },
                }
        );
    },
    onLaunch: function () {
        // Load QSClassifierStore
        /*thatClassification.getQSClassifierStore().load({
         callback: thatClassification.onQSClassifiersLoad,
         scope: thatClassification
         });*/
        // Load ClassifierStore
        /*thatClassification.getClassifierStore().load({
         callback: thatClassification.onClassifiersLoad,
         scope: thatClassification
         });*/
    },
    lingunetTextfieldChanged: function (pTextField) {
        console.log("textchanged");
        if (thatClassification.inputTextChangeInProgress == true)
            return;
        thatClassification.inputTextChangeInProgress = true;
//	                	  thatClassification.getInputText().setValue(pTextField.getValue());
        thatClassification.lingunetParameters.text = pTextField.getValue();
        thatClassification.lingunetParameters.content = DataHolder.getText();
        thatClassification.inputTextChangeInProgress = false;

    },
    qsTextfieldChanged: function (pTextField) {
        if (thatClassification.inputTextChangeInProgress == true)
            return;
        thatClassification.inputTextChangeInProgress = true;
//	                	  thatClassification.getInputText().setValue(pTextField.getValue());
        thatClassification.classifierParameters.text = pTextField.getValue();
        thatClassification.inputTextChangeInProgress = false;
    },
    textareaChanged: function (pTextArea) {
        if (thatClassification.inputTextChangeInProgress == true)
            return;
        thatClassification.inputTextChangeInProgress = true;
        thatClassification.getQsInputText().setValue(pTextArea.getValue());
        thatClassification.classifierParameters.text = pTextArea.getValue();
        thatClassification.inputTextChangeInProgress = false;
    },
    openTextEditor: function () {
        var d2Catonline = thatClassification.getD2Catonline();
        thatClassification.getGroupTabPanel().setActiveTab(d2Catonline);
        thatClassification.getInputSelection().expand();
        thatClassification.getInputText().focus(true);
    },
    downloadTEI: function () {
        var lLocation = window.location;
        window.location = lLocation + '/d2cat?cmd=downloadtei&teifile=' + thatClassification.currentResult.teifile;
    },
    qsTextfieldEnter: function (pTextfield, pEvent) {
        if (pEvent.getKey() == pEvent.ENTER) {
            thatClassification.executeClassification(thatClassification.classifierParameters);
        }
    },
    classify: function () {
//	                	  console.log(thatClassification.getInputText().getValue());
//	                	  console.log(thatClassification.getInputText().getValue().length > 0)
//	                	  if (thatClassification.getInputText().getValue().length > 0) {
//	                	  var output = {
//	                	  command: "fileupload",
//	                	  payload: {content: thatClassification.getInputText().getValue(), name: "Text input"}
//	                	  };
//	                	  websocket.send(JSON.stringify(output));
//	                	  }
        if ((thatInputselection.files.length > 0 || thatClassification.classifierParameters.text !== undefined)) {
            if ((Object.keys(thatClassification.getOptions().optionValues()).length !== 0 && JSON.stringify(thatClassification.getOptions().optionValues()) !== JSON.stringify({}))) {
                var output = {
                    command: "process",
                    payload: {text: thatClassification.classifierParameters.text, options: thatClassification.getOptions().optionValues()}
                };

                var opt = [];
                for (var i in thatClassification.getOptions().optionValues()) {
                    opt.push(i)
                    var tmp = "";
                    for (var j in thatClassification.getOptions().optionValues()[i]) {
                        if (tmp.length > 0)
                            tmp += ",";
                        tmp += thatClassification.getOptions().optionValues()[i][j];
                    }
                    opt.push(tmp);
                }

                var files = [];
                var fileNames = [];
                if (thatInputselection.plaintext) {
                    files.push(thatInputselection.plaintext);
                    fileNames.push("plaintext");
                }
                if (thatInputselection.files.length > 0) {
                    files = files.concat(thatInputselection.files);
                    fileNames = fileNames.concat(thatInputselection.fileNames);
                }


                data = {
                    files: {item: files},
                    fileNames: {item: fileNames},
                };

                $.soap({
                    url: 'http://service.hucompute.org/services-webservices/TextImager?wsdl/',
                    method: 'ns2:processMulti',
                    envAttributes: {
                        'xmlns:ns2': 'http://webservices.services.hucompute.org/'
                    },
                    data: {
                        files: {item: files},
                        fileNames: {item: fileNames},
                        options: {item: opt},
                    },
                    success: function (SOAPResponse) {
                        thatClassification.onClassificationSuccess(SOAPResponse.content.children[0].textContent);
                    },
                    error: function (SOAPResponse) {
                        console.log(SOAPResponse);
                    }
                });
//                thatClassification.lMonitor.show();
//                thatClassification.lMonitor.updateStatus("test");
            }
            else {
                Ext.Msg.alert('Status', 'You didn\'t select any methods from the NLP circle.');
            }
        }
        else {
            Ext.Msg.alert('Status', 'You didn\'t insert a text.');
        }
    },
    getdata: function () {
        if ((thatInputselection.files.length > 0 || thatClassification.classifierParameters.text !== undefined)) {
            if ((Object.keys(thatClassification.getOptions().optionValues()).length !== 0 && JSON.stringify(thatClassification.getOptions().optionValues()) !== JSON.stringify({}))) {
                thatClassification.isgetdata = true;
                thatClassification.classify();
            }
            else {
                Ext.Msg.alert('Status', 'You didn\'t select any methods from the NLP circle.');
            }
        }
        else {
            Ext.Msg.alert('Status', 'You didn\'t insert a text.');
        }
    },
    analyze: function () {
        thatClassification.executeClassification(thatClassification.lingunetParameters);

        console.log("ANALISIIIIIIERE!");
    },
    onAnalyzeSuccess: function (pResponse) {
        console.log("Analyze Succes");
        DataHolder.setLinguNetJson(pResponse.responseText);
    },
    onClassificationSuccess: function (pResponse) {

        if (thatClassification.isgetdata) {
            DataHolder.setXML(pResponse);
            var xml = new XMLSerializer().serializeToString(DataHolder.getXML().documentElement);
            var blob = new Blob([xml], {
                type: "text/plain;charset=utf-8;",
            });
            saveAs(blob, "data.xml");
            console.log(Ext.getCmp("classificationprogress"));
            location.reload();  // Am besten so machen, dass alles von alleine initialisiert.

            //	                		  Ext.getCmp("classificationprogress").hide();
            //	                		  Ext.getCmp("inputText").setValue("");
            //	                		  d3.select("#classificationprogress").transition().attr("visibility", "hidden");
        }
        else {
            DataHolder.setXML(pResponse);
            console.log(DataHolder.getJson());
            thatClassification.getOptions().hide();
            var lLanguageNote = '';
            thatClassification.getD2Catonline().show();
            thatClassification.lMonitor.hide();
//	                		  thatClassification.getTextViewLemma().setHtml(pResponse.html);

        }
        console.log(DataHolder.getXML());
    }

});
