Ext.define('D2Cat.controller.D2CatOnline', {
    extend: 'Ext.app.Controller',

    refs: [
    ],


    init: function() {
        // Start listening for events on views
        this.control(
        );
    }


});
