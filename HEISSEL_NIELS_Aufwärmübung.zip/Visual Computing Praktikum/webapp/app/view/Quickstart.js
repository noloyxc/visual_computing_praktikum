Ext.define('D2Cat.view.Quickstart', {
    extend: 'Ext.Panel',
    alias: 'widget.quickstart',
    requires: [
    ],
    border: false,
    bodyStyle: {"background-color": "#f5f5f5"},
    initComponent: function () {
        this.layout = {
            type: 'hbox',
        };

        this.items = [
            {
                xtype: 'label',
                margin: '5 0 0 5',
                html: '<a href="/index.html""><img src="https://hucompute.org/wp-content/uploads/2015/09/ehd-logos5-27.png" width="150" height="45"/></a>',
            },
        ]
        this.callParent();
    }
});