﻿Ext.define('D2Cat.view.VizTabPanel', {
    alias: 'widget.viztabpanel',
    extend: 'Ext.tab.Panel',
    flex: 5,
    xtype: 'viztabpanel',
    frame: true,
    title: "Visualization",
    region: 'center',
    margins: '4 0 4 0',
    split: true,
    collapsible: true,
    collapseDirection: "right",
    tabPosition: 'bottom',
    id: 'viztabpanel',
    layout: 'fit',
//    tbar: {
//        xtype: 'toolbar',
//        cls: 'x-panel-header',
//        items: [
//            //your items
//        ]
//    },
    tools: [{
            type: 'save',
            id: 'save',
            hidden: true,
            handler: function (e, toolEl, panel, tc) {

            },
        },
        {
            type: 'refresh',
            id: "changeVizBtn",
            hidden: true,
            handler: function (e, toolEl, panel, tc) {

            },
        }],
    items: [
//        {
//            xtype: 'panel',
//            title: 'Start',
//            class: 'start',
//            id: 'start',
//            requires: "DocElement",
//            style: 'height:100%; width: 100%; position:relative',
//            html: '<span class="choosing">Choose one of the vizualization from the tabpanel </span>'
////                                hide: true,
//        },
        {
            xtype: 'fingerViz',
            title: 'FingerViz',
            id: 'fingerViz',
            requires: "Token",
//            hidden: true,
            textNeeded: 1,
            autoScroll: true,
            tabConfig: {
                tooltip: 'This panel shows the statistics.'
            }
        }
    ],
    listeners: {
        render: function () {
            this.items.each(function (i, j) {
                i.tab.on('click', function () {
                    if (i.xtype === "tabpanel") {
                        var scrollPanel = "#scrollpanel-innerCt";
                        thatD2Cat.scrollPan = d3.selectAll(scrollPanel);
                        Ext.getCmp("start").tab.destroy();
                        d3.selectAll(".scrollPanel").hide;
                        i.getActiveTab().initPage();
                        i.getActiveTab().initNaviClick();
                        i.getActiveTab().initSentenceClick();
                        if (typeof lastTab != 'undefined') {
                            thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
                        }
//                                thatD2Cat.lastTab = i;
                        lastTab = i.getActiveTab();
                    } else {
                        var scrollPanel = "#scrollpanel-innerCt";
                        d3.selectAll(".scrollPanel").hide;
                        i.initPage();
                        i.initNaviClick();
                        i.initSentenceClick();
                        if (typeof lastTab != 'undefined') {
                            thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
                        }
//                                thatD2Cat.lastTab = i;
                        lastTab = i;
//                                alert(i.title);
                    }
                });
            });
        },
        resize: function () {
        },
        beforetabchange: function (d, i, j, k) {
//            console.log(j);
            try {
                j.exitPage();
            } catch (err) {
//                console.log("Keine Exit-Funktion");
            }
            if (i.xtype === "tabpanel") {
                Ext.getCmp("start").tab.destroy();
                d3.selectAll(".scrollPanel").hide;
                thatD2Cat.doublePan.collapse();
                i.getActiveTab().initPage();
                i.getActiveTab().initNaviClick();
                i.getActiveTab().initSentenceClick();
                if (typeof lastTab != 'undefined') {
                    thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
                }
                lastTab = i.getActiveTab();
            } else {
                Ext.getCmp("start").tab.destroy();
                if (i.xtype === "information") {
                    Ext.getCmp("lefttabpanel").flex = 20;
                    Ext.getCmp("masterpanel").doLayout();
                    thatD2Cat.rightTab.hide();
                    thatD2Cat.rightTree.hide();
                } else {
                    if (i.textNeeded !== 2) {
                        thatD2Cat.leftTab.flex = 3;
                        thatD2Cat.rightTab.hide();
                        thatD2Cat.rightTree.hide();
                        Ext.getCmp("masterpanel").doLayout();
                    } else {
                        thatD2Cat.leftTab.flex = 13;
                        thatD2Cat.rightTab.flex = 13;
                        thatD2Cat.leftTab.show();
                        thatD2Cat.leftTab.expand();
                        thatD2Cat.rightTab.show();
                        thatD2Cat.rightTree.show();
                        thatD2Cat.leftTab.expand();
                        thatD2Cat.rightTab.expand();
                        Ext.getCmp("masterpanel").doLayout();
//                thatD2Cat.tree.expand();

                    }
                }
                d3.selectAll(".scrollPanel").hide;
                i.initPage();
                i.initNaviClick();
                i.initSentenceClick();
                if (typeof lastTab != 'undefined') {
                    thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
                }
                lastTab = i;
            }
        },
        tabChange: function (d, i, j) {
            var tmpActiveTab = this.getActiveTab();
            i.initNaviClick();
            i.initSentenceClick();
            i.initChart(tmpActiveTab);
        },
        beforecollapse: function (d) {
            if (!Ext.getCmp("righttabpanel").hidden)
                Ext.getCmp("righttabpanel").collapse();
            Ext.getCmp("lefttabpanel").hideCollapseTool = true;
            return false;
        }
    }
})
