Ext.define('D2Cat.view.Viewport', {
    extend: 'Ext.container.Viewport',
    layout: 'fit',
    requires: [
        'D2Cat.view.Quickstart',
        'D2Cat.view.D2CatOnline',
    ],
    bodyStyle: {"background-color": "black"},
    initComponent: function () {
        if (true) {
            if (window.location.href.split("&file=").length > 1){
                DataHolder.setTestFile(window.location.href.split("&file=")[1]);
            }
            else
                DataHolder.setTestFile("./ObamaMerkelGoethe.xml");
            this.items = {
                layout: {
                    type: 'fit'
                },
                defaults: {
                    border: false
                },
                items: [
                    {
                        xtype: 'd2catonline'
                    }
                ]
            };
            this.callParent();
        }
    }
});