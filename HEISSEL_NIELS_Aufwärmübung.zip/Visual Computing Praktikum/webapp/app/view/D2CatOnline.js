﻿Ext.define('D2Cat.view.D2CatOnline', {
    extend: 'Ext.Panel',
    alias: 'widget.d2catonline',
    title: 'DDC classifier',
    border: true,
    header: false,
    padding: '0 4 0 0',
    id: "masterpanel",
    bodyStyle: {"background-color": "#f5f5f5"},
    layout: {
        type: 'border',
        align: 'stretch'
    },
    listeners: {
        aftershow: function (d) {
        },
        beforeshow: function (d) {
            var naviStructure = [];
            var rightNaviStructure = [];
            var documents = DataHolder.getDocument();
            var count = 1;
            var tabpanel = Ext.getCmp("viztabpanel");
            var dataJson = DataHolder.getJson().XMI;
            for (var i = 0; i < tabpanel.items.items.length; i++) {
                var tab = tabpanel.items.items[i];
//                console.log(dataJson);
                if (((![].concat(dataJson.DocElement)[0][tab.requires]) && (!dataJson[tab.requires])) || (tab.textNeeded > [].concat(dataJson.DocElement).length))
                    Ext.getCmp(tab.id).setDisabled(true);
            }

            var docs = [];
            for (var k = 0; k < documents.length; k++) {
                try {
                    var tmpDocParagraphs = DataHolder.selectCovered(documents[k].Paragraph, DataHolder.selectCovered(documents[k].Sentence));
//                    console.log(tmpDocParagraphs);
                    var paras = [];
                    var paras2 = [];
                    for (var i = 0; i < tmpDocParagraphs.length; i++) {
                        var paraSentences = tmpDocParagraphs[i].Sentence;
                        var sentences = [];
                        var sentences2 = [];
                        try {
                            for (var j = 0; j < paraSentences.length; j++) {
                                sentences.push({text: "Sentence " + count, leaf: true, index: j, type: "sentence", identical: "nlp" + paraSentences[j]["_xmi:id"]});
                                sentences2.push({text: "Sentence " + count, leaf: true, index: j, type: "sentence", identical: "nlp" + paraSentences[j]["_xmi:id"]});
                                count++;
                            }
                        } catch (err) {
//                            console.log("Paragraph hat keinen Sentence.")
                        }
                        var para = {text: "Paragraph " + (i + 1), type: "paragraph", index: i, expanded: false, children: sentences, identical: "nlp" + tmpDocParagraphs[i]["_xmi:id"]};
                        var para2 = {text: "Paragraph " + (i + 1), type: "paragraph", index: i, expanded: false, children: sentences2, identical: "nlp" + tmpDocParagraphs[i]["_xmi:id"]};
                        paras.push(para);
                        paras2.push(para2);
                    }
                } catch (err) {
//                    console.log("Paragraph hat keinen Sentence.")

                    var paraSentences = documents[k].Sentence;
                    var paras = [{text: "Paragraph " + 0, type: "paragraph", index: 0, expanded: false, children: sentences, identical: "nlp0"}];
                    var paras2 = [{text: "Paragraph " + 0, type: "paragraph", index: 0, expanded: false, children: sentences2, identical: "nlp0"}];
                    var sentences = [];
                    var sentences2 = [];
                    try {
                        for (var j = 0; j < paraSentences.length; j++) {
                            sentences.push({text: "Sentence " + count, leaf: true, index: j, type: "sentence", identical: "nlp" + paraSentences[j]["_xmi:id"]});
                            sentences2.push({text: "Sentence " + count, leaf: true, index: j, type: "sentence", identical: "nlp" + paraSentences[j]["_xmi:id"]});
                            count++;
                        }
                    } catch (err) {
//                        console.log("Paragraph hat keinen Sentence.")
                    }
                }
//                var docs = {text: "Kapitel " + (k+1), expanded: false, index: k, type: "document", children: paras, identical: "nlp" + documents[k]["_xmi:id"]};
//                var docs2 = {text: "Kapitel " + (k+1), expanded: false, index: k, type: "document", children: paras2, identical: "nlp" + documents[k]["_xmi:id"]};
                var docs = {text: documents[k]["_name"], expanded: false, index: k, type: "document", children: paras, identical: "nlp" + documents[k]["_xmi:id"]};
                var docs2 = {text: documents[k]["_name"], expanded: false, index: k, type: "document", children: paras2, identical: "nlp" + documents[k]["_xmi:id"]};
                rightNaviStructure.push(docs2);
                naviStructure.push(docs);
            }



            var root = thatD2Cat.leftTree.getRootNode();
            var rightRoot = thatD2Cat.rightTree.getRootNode();
            rightRoot.appendChild(rightNaviStructure);
            root.appendChild(naviStructure);
        },
//        afterShow: function () {
//        },
        add: function (c, i) {
            if (i.xtype == 'bordersplitter')
                i.width = "4px";
        }
    },
    requires: [
        'D2Cat.view.VizTabPanel',
        'D2Cat.view.FingerViz',
    ],
    initComponent: function () {
        thatD2Cat = this;
        thatD2Cat.lastTab;
        thatD2Cat.openedTabs = [];
        thatD2Cat.rightOpenedTabs = [];
        thatD2Cat.leftTree = Ext.create('Ext.tree.TreePanel', {
            id: 'leftNavigationPanel',
            frame: true,
            title: 'Navigation',
            autoHeight: true,
            autoDestroy: true,
            split: true,
            region: 'west',
            collapsible: true,
            autoScroll: false,
            margins: '4 0 4 4',
            width: 200,
            root: {
                expanded: true,
                leaf: false,
                text: "Corpus",
                children: []
            },
            listeners: {
                itemclick: function (s, r) {
                    var leftTabs = Ext.getCmp('lefttabpanel');
                    if (r.raw.type === "document") {
                        var index = thatD2Cat.openedTabs.indexOf("left" + r.raw.identical);
                        if (index >= 0) {
                            var tab = Ext.getCmp("left" + r.raw.identical);
                            leftTabs.setActiveTab(tab);
                        } else {
                            var html = DataHolder.getHTML(r.raw.index, ["Paragraph", "Sentence"]);
                            thatD2Cat.openedTabs.push("left" + r.raw.identical);
                            var startTab = Ext.getCmp("leftstart");
                            if (startTab)
                                startTab.destroy();
                            var newLeftTab = new Ext.Panel({
                                flex: 5,
                                html: html,
                                id: "innerleft" + r.raw.identical,
                                border: false,
                                autoScroll: true
                            });
                            var newLeftScrollPanel = new Ext.Panel({
                                width: 20,
                                xtype: 'panel',
                                border: false,
                                class: "scrollpanel",
                                id: 'scrollpanelleft' + r.raw.identical,
                                hidden: true,
                                componentCls: 'left-border',
                            });
                            var mid = new Ext.Panel({
                                flex: 3,
                                title: r.raw.text,
                                autodestroy: false,
                                frame: true,
                                closable: true,
                                index: r.raw.index,
                                id: "left" + r.raw.identical,
                                border: false,
                                collapsible: true,
                                collapseDirection: "left",
                                hideCollapseTool: false,
                                style: "border: none;",
                                autoScroll: true,
                                split: true,
                                html: html,
                                margins: '0 0 0 0',
                                layout: {
                                    type: 'hbox',
                                    align: 'stretch'
                                },
                                listeners: {
                                    resize: function (d, i, j) {
                                    },
                                    beforeClose: function (a, b) {
//                                        a.destroy();
                                        var index = thatD2Cat.openedTabs.indexOf(a.id);
                                        thatD2Cat.openedTabs.splice(index, 1);
                                        if (thatD2Cat.openedTabs.length === 0) {
                                            var start = {
                                                xtype: 'panel',
                                                title: 'Start',
                                                id: 'leftstart',
                                                class: 'start',
                                                html: '<span class="choosing">Choose one of the documents from the navigation.</span>'
                                            };
                                            leftTabs.add(start);
                                        }

                                    }
                                }
                                ,
                                items: [
                                    newLeftTab,
                                    newLeftScrollPanel
                                ]
                            });
                            leftTabs.add(mid).show();
                            leftTabs.setActiveTab(mid);
                        }
                    }
                }
            }
        });
        thatD2Cat.rightTree = Ext.create('Ext.tree.TreePanel', {
            id: 'rightNavigationPanel',
            frame: true,
            title: 'Navigation',
            autoHeight: true,
            region: 'east',
            hidden: true,
//            collapsed : true,
            collapsible: true,
            autoScroll: false,
            margins: '4 4 4 0',
            width: 200,
            root: {
                expanded: true,
                leaf: false,
                text: "Corpus",
                children: []
            },
            listeners: {
                itemclick: function (s, r) {
                    var rightTabs = Ext.getCmp('righttabpanel');
                    rightTabs.setTitle(r.raw.text);
                    if (r.raw.type === "document") {
                        var index = thatD2Cat.rightOpenedTabs.indexOf("right" + r.raw.identical);
                        if (index >= 0) {
                            var tab = Ext.getCmp("right" + r.raw.identical);
                            rightTabs.setActiveTab(tab);
                        } else {
                            var html = DataHolder.getHTML(r.raw.index, ["Paragraph", "Sentence"]);
                            thatD2Cat.rightOpenedTabs.push("right" + r.raw.identical);
                            var startTab = Ext.getCmp("rightstart");
                            if (startTab)
                                startTab.destroy();
                            var newRightTab = new Ext.Panel({
                                flex: 5,
                                id: "innerright" + r.raw.identical,
                                html: html,
                                border: false,
                                autoScroll: true
                            });
                            var newRightScrollPanel = new Ext.Panel({
                                width: 20,
                                xtype: 'panel',
                                border: false,
                                class: "scrollpanel",
                                id: 'scrollpanelright' + r.raw.identical,
                                autoScroll: false,
                                hidden: true,
                                componentCls: 'right-border',
                            });
                            var mid = new Ext.Panel({
                                flex: 3,
                                title: r.raw.text,
                                autodestroy: false,
                                frame: true,
                                closable: true,
                                index: r.raw.index,
                                id: "right" + r.raw.identical,
                                border: false,
                                collapsible: true,
                                collapseDirection: "right",
                                hideCollapseTool: false,
                                style: "border: none;",
                                autoScroll: true,
                                split: true,
                                html: html,
                                margins: '0 0 0 0',
                                layout: {
                                    type: 'hbox',
                                    align: 'stretch'
                                },
                                listeners: {
                                    resize: function (d, i, j) {
                                    },
                                    beforeClose: function (a, b) {
//                                        a.destroy();
                                        var index = thatD2Cat.rightOpenedTabs.indexOf(a.id);
                                        thatD2Cat.rightOpenedTabs.splice(index, 1);
                                        if (thatD2Cat.rightOpenedTabs.length === 0) {
                                            var start = {
                                                xtype: 'panel',
                                                title: 'Start',
                                                id: 'rightstart',
                                                class: 'start',
                                                html: '<span class="choosing">Choose one of the documents from the navigation.</span>'
                                            };
                                            rightTabs.add(start);
                                        }

                                    }
                                }
                                ,
                                items: [
                                    newRightScrollPanel,
                                    newRightTab

                                ]
                            });
                            rightTabs.add(mid).show();
                            rightTabs.setActiveTab(mid);
                        }
                    }
                }
            }
        });

        var splitter = Ext.create('Ext.resizer.Splitter', {
            height: "1px",
            autoShow: true
        });

        thatD2Cat.leftTab = Ext.create('Ext.tab.Panel', {
            flex: 3,
            frame: true,
            collapsible: true,
            autoDestroy: false,
            activeTab: 0,
            title: "Document",
            region: 'west',
            margins: '4 0 4 0',
            split: true,
            tabPosition: 'bottom',
            id: 'lefttabpanel',
//            style: 'padding-top: 8px',
            items: [
                {
                    xtype: 'panel',
                    title: 'Start',
                    id: 'leftstart',
                    class: 'start',
                    html: '<span class="choosing">Choose one of the documents from the navigation.</span>'
                }
            ],
            listeners: {
                tabchange: function (a, b, c) {
                    var tmpActiveTab = Ext.getCmp("viztabpanel").getActiveTab();
                    if (tmpActiveTab.id !== "start") {
                        tmpActiveTab.initSentenceClick(b.index);
                        tmpActiveTab.initNaviClick();
                        tmpActiveTab.initChart(tmpActiveTab);
                    }
                },
                beforecollapse: function (d) {
                    thatD2Cat.leftTree.collapse();
                    Ext.getCmp("righttabpanel").flex = 3;
                },
                beforeexpand: function (d) {
                    Ext.getCmp("righttabpanel").flex = 15;
                }
            }
        });
        thatD2Cat.rightTab = Ext.create('Ext.tab.Panel', {
            flex: 3,
            frame: true,
            collapsible: true,
            autoDestroy: false,
            region: 'east',
            margins: '4 4 4 0',
            split: true,
            tabPosition: 'bottom',
            id: 'righttabpanel',
            layout: 'fit',
            hidden: true,
            items: [
                {
                    xtype: 'panel',
                    title: 'Start',
                    id: 'rightstart',
                    class: 'start',
                    html: '<span class="choosing">Choose one of the documents from the navigation.</span>'
                }
            ],
            listeners: {
                tabchange: function (a, b, c) {
                    var tmpActiveTab = Ext.getCmp("viztabpanel").getActiveTab();
                    if (tmpActiveTab.id !== "start") {
                        tmpActiveTab.initSentenceClick(b.index);
                        tmpActiveTab.initNaviClick();
                        tmpActiveTab.initChart(tmpActiveTab);
                    }
                },
                beforecollapse: function (d) {
                    thatD2Cat.rightTree.collapse();
                    Ext.getCmp("lefttabpanel").flex = 3;
                    Ext.get("lefttabpanel").collapsible = false;
                },
                beforeexpand: function (d) {
                    Ext.getCmp("lefttabpanel").flex = 15;
                }
            }
        });
        this.items = [
            thatD2Cat.leftTree,
            thatD2Cat.leftTab,
            thatD2Cat.tabpanel = {
                xtype: 'viztabpanel',
            },
//            thatD2Cat.zeitreiheninput = {
//                xtype: 'zeitreiheninput',
//            },
//            thatD2Cat.statisticsinput = {
//                xtype: 'statisticsinput',
//            },
//            thatD2Cat.semanticrelationinput = {
//                xtype: 'semanticrelationinput',
//            },
//            thatD2Cat.rightTab,
//            thatD2Cat.rightTree
        ];
        itemsCopy = this.items;
        this.callParent();
        if (true) {
            this.show();
        } else
            this.hide();
    }
    ,
    resetView: function () {
        var f;
        while (f = thatD2Cat.items.first()) {
            thatD2Cat.remove(f, true);
        }
        thatD2Cat.add(itemsCopy);
        thatD2Cat.doLayout();
    },
    markElements2: function (panel, ids, colors, showScrollpanel, items) {
        function hexToR(h) {
            return parseInt((cutHex(h)).substring(0, 2), 16)
        }
        function hexToG(h) {
            return parseInt((cutHex(h)).substring(2, 4), 16)
        }
        function hexToB(h) {
            return parseInt((cutHex(h)).substring(4, 6), 16)
        }
        function cutHex(h) {
            return (h.charAt(0) == "#") ? h.substring(1, 7) : h
        }

//                thatD2Cat.unmarkElements(panel, items);
//        Ext.getCmp("viztabpanel").getActiveTab().initPage();
        var doc = DataHolder.getDocument(panel.index);
        var tmpPanel = d3.select("#inner" + panel.id + "-innerCt");
        tmpPanel.selectAll("span").style("background-color", "transparent");
        if (showScrollpanel) {
            Ext.getCmp("scrollpanel" + panel.id).show();
            var tmpScrollpanel = d3.select("#scrollpanel" + panel.id + "-innerCt");
            tmpScrollpanel.select("svg").remove();
            var docBegin = doc["_begin"];
            var completeTextHeight = doc["_end"] - docBegin;
            var scrollpanelHeight = tmpScrollpanel[0][0].clientHeight;
            var scrollpanelWidth = tmpScrollpanel[0][0].clientWidth;
            var svg = tmpScrollpanel.append("svg")
                    .attr("width", "100%")
                    .attr("height", "100%");
            for (var i in colors) {
                var tmpElement = DataHolder.getElementById(ids[i].replace("#nlp", ""))[0];
                var tmpOffsetHeight = tmpElement.attributes.end.value - tmpElement.attributes.begin.value;
                var tmpOffsetTop = tmpElement.attributes.begin.value - docBegin;
                svg.append("rect").attr("class", "scrollPanelRect").attr("x", 0).attr("id", ids[i]).attr("color", colors[i]).attr("y", (tmpOffsetTop) / (completeTextHeight / scrollpanelHeight)).attr("width", scrollpanelWidth).attr("height", tmpOffsetHeight / (completeTextHeight / scrollpanelHeight)).attr("fill", colors[i])
                        .style("stroke", "4px").style("stroke-opacity", 0).on("click", function (d) {
                    var tmpId = this.id;
                    var tmpColor = this.getAttribute("color");
                    d3.select("#inner" + panel.id + "-body")[0][0].scrollTop = d3.select(tmpId)[0][0].offsetTop - (scrollpanelHeight / 2);
                    d3.select(tmpId).transition().duration(1000).style("background-color", "yellow");
                    setTimeout(function () {
                        d3.select(tmpId).transition().duration(1000).style("background-color", tmpColor);
                    }, 1000);
                });
            }
        }
        for (var id in ids) {
            try {
                tmpPanel.selectAll(ids[id]).style("background-color", colors[id]).style("color", function () {
                    return "black";
                });
            } catch (err) {
            }
        }
    },
    markElements: function (panel, ids, colors, showScrollpanel, annotation) {
        var doc = DataHolder.getDocument(panel.index);
        var tmpPanel = d3.select("#inner" + panel.id + "-innerCt");
        tmpPanel.selectAll("span").style("background-color", "transparent");
        if (showScrollpanel) {
            Ext.getCmp("scrollpanel" + panel.id).show();
            var tmpScrollpanel = d3.select("#scrollpanel" + panel.id + "-innerCt");
            tmpScrollpanel.select("svg").remove();
            var docBegin = doc["_begin"];
            var completeTextHeight = doc["_end"] - docBegin;
            var scrollpanelHeight = tmpScrollpanel[0][0].clientHeight;
            var scrollpanelWidth = tmpScrollpanel[0][0].clientWidth;
            var svg = tmpScrollpanel.append("svg")
                    .attr("width", "100%")
                    .attr("height", "100%");
            var tmpElements = DataHolder.getElementsByIds(annotation, ids);
            for (var i in tmpElements) {
                var tmpElement = tmpElements[i];
                var tmpOffsetHeight = tmpElement.attributes.end.value - tmpElement.attributes.begin.value;
                var tmpOffsetTop = tmpElement.attributes.begin.value - docBegin;
                svg.append("rect").attr("class", "scrollPanelRect").attr("x", 0).attr("id", ids[i]).attr("color", colors[i]).attr("y", (tmpOffsetTop) / (completeTextHeight / scrollpanelHeight)).attr("width", scrollpanelWidth).attr("height", tmpOffsetHeight / (completeTextHeight / scrollpanelHeight)).attr("fill", colors[i])
                        .style("stroke", "4px").style("stroke-opacity", 0).on("click", function (d) {
                    var tmpId = this.id;
                    var tmpColor = this.getAttribute("color");
                    d3.select("#inner" + panel.id + "-body")[0][0].scrollTop = d3.select(tmpId)[0][0].offsetTop - (scrollpanelHeight / 2);
                    d3.select(tmpId).transition().duration(1000).style("background-color", "yellow");
                    setTimeout(function () {
                        d3.select(tmpId).transition().duration(1000).style("background-color", tmpColor);
                    }, 1000);
                });
            }
        }
        for (var id in ids) {
            try {
                tmpPanel.selectAll(ids[id]).style("background-color", colors[id]).style("color", function () {
                    return "black";
                });
            } catch (err) {
            }
        }
    },
    unmarkElements: function (panel, items) {
        if (!items)
            var items = ["Paragraph", "Sentence"];
        if (panel.class !== "start") {
            Ext.getCmp("scrollpanel" + panel.id).hide();
            var tmpPanel = d3.select("#inner" + panel.id + "-innerCt");
            tmpPanel.html(DataHolder.getHTML(panel.index, items));
        }
    },
    beforeTabChangeFunc: function (d, i, j, k) {

        if (i.xtype === "tabpanel") {
            Ext.getCmp("start").tab.destroy();
            thatD2Cat.scrollPanel.hide();
            thatD2Cat.doublePan.collapse();
            i.getActiveTab().initPage();
            i.getActiveTab().initNaviClick();
            i.getActiveTab().initSentenceClick();
            if (typeof lastTab != 'undefined') {
                thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
            }
            lastTab = i.getActiveTab();
        } else {
            Ext.getCmp("start").tab.destroy();
            console.log("TEEEEEEEEEEEST");
            if (i.textNeeded !== 2) {
                thatD2Cat.leftTab.flex = 3;
                thatD2Cat.mid.show();
                thatD2Cat.mid.expand();
                thatD2Cat.rightTab.hide();
                thatD2Cat.rightTree.hide();
            } else {
                thatD2Cat.leftTab.flex = 15;
                thatD2Cat.rightTab.flex = 15;
                thatD2Cat.leftTab.show();
                thatD2Cat.leftTab.expand();
                thatD2Cat.rightTab.show();
                thatD2Cat.rightTree.show();
                thatD2Cat.leftTab.expand();
                thatD2Cat.rightTab.expand();
//                thatD2Cat.tree.expand();

            }
//            thatD2Cat.scrollPanel.hide();
            thatD2Cat.doublePan.collapse();
            i.initPage();
            i.initNaviClick();
            i.initSentenceClick();
            if (typeof lastTab != 'undefined') {
                thatD2Cat.leftTree.removeListener('itemclick', lastTab.naviClickFunction);
            }
            lastTab = i;
        }
    }
});
