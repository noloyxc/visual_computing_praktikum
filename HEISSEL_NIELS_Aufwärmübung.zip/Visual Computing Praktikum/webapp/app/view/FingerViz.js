Ext.define('D2Cat.view.FingerViz', {
    extend: 'Ext.Panel',
    alias: 'widget.fingerViz',
    title: 'FingerViz',
    border: false,
    xtype: 'fingerViz',
    layout: {
        type: 'border',
        align: 'stretch'
    },
    bodyStyle: {
        'background': 'white'
    },
    initComponent: function () {
        thatVisualizer = this;
        thatVisualizer.outOfRange = true;
        this.items = [
            {
                xtype: 'panel',
                region: 'center',
                autoscroll: false,
                id: 'fingervizpanel',
                border: false,
                html: '<span class="choosing">Choose one of the  documents from the navigation.</span>',
            },
        ];
        this.callParent();
    },
    initPage: function () {
    },
    exitPage: function () {
    },
    initNaviClick: function () {
    },
    naviClickFunction: function (d, i) {
    },
    initSentenceClick: function () {
    }, // Wird aufgerufen wenn das Visualization-Panel geöffnet wird.
    initChart: function (panel) {
        var panelId = '#fingervizpanel-innerCt';
        var documentIndex = thatD2Cat.leftTab.getActiveTab().index;    // index of the currently selected Document
        //Prüft, ob ein Dokument ausgewählt wurde.
        if (documentIndex === undefined) {                             // Wenn kein Dokument selektiert wurde, dann wird auch nix  visualisiert.
            console.log("No Document selected");
            return false;
        }
        else {                                                         // Wenn ein Dokument selektiert wurde dann wird visualisiert.
            console.log("Document selected. Visualization initializing.");
            d3.select(panelId).select("span").style("display", "none");
            d3.selectAll(panelId).select("svg").remove();
        }

        var width = panel.getWidth();                                  // Breite des Visualisierungsteils
        var height = panel.getHeight();                                // Hoehe des Visualisierungsteils
        var tmpDocument = DataHolder.getDocument(documentIndex);       // Speichert die Daten, des aktuell ausgewaehlten Dokuments in  tmpDocument.
        var tmpDocEntitys = tmpDocument.Entity;                        // Speichert die Entitäten des aktuellen Dokuments in tmpDocEntitys.
        console.log(tmpDocEntitys);

        var div = d3.select(panelId);

        // --- Unter Häufigkeiten der Entitäten verstehe ich die Häufigkeit der verschiedenen Entitätstypen. ---
        ////////////////
        // Collect information about entitys.
        var entitys = {"Person": 0, "Location": 0, "NamedEntity": 0, "Organization": 0};
        for (i = 1; i < tmpDocEntitys.length; i++) {
            console.log(tmpDocEntitys[i]._value);
            entitys[tmpDocEntitys[i]._value.toString()] += 1;
        };

        console.log(entitys);

        // Store data in array of dictionaries.
        const data = [
            {"state": "Person", "value": entitys["Person"]},
            {"state": "Location", "value": entitys["Location"]},
            {"state": "NamedEntity", "value": entitys["NamedEntity"]},
            {"state": "Organization", "value": entitys["Organization"]}
        ];
        ///////////////////////
        // Chart Size Setup
        var margin = { top: 35, right: 30, bottom: 30, left: 40 };


        var svg = div.append("svg")
            .attr("width", width)
            .attr("height", height)
            .append("g")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        ///////////////////////
        // Scales
        var x = d3.scale.ordinal()
            .domain(data.map(function(d) { return d['state']; }))
            .rangeRoundBands([0, width], .1);

        var y = d3.scale.linear()
            .domain([0, d3.max(data, function(d) { return d['value']; }) * 1.1])
            .range([height - 0.15*height, 0]);

        ///////////////////////
        // Axis
        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom");

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left");

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + height - ")")
            .attr("transform", "translate(" + (-10) + ")")
            .call(xAxis);

        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis);

        ///////////////////////
        // Title
        svg.append("text")
            .text('Häufigkeiten der Entitäten:')
            .attr("text-anchor", "middle")
            .attr("class", "graph-title")
            .attr("y", -10)
            .attr("x", width / 2.0);

        ///////////////////////
        // Bars
        var bar = svg.selectAll(".bar")
            .data(data)
            .enter().append("rect")
            .attr("class", "bar")
            .attr("x", function(d) { return x(d['state']); })
            .attr("y", height )
            .attr("width", x.rangeBand() -25)
            .attr("height", 0);                     // Height will appear through transition

        bar.transition()
            .duration(1500)
            .ease("elastic")
            .attr("y", function(d) { return y(d['value']) ; })
            .attr("height", function(d) { return height - y(d['value']) - 0.15*height; })

        ///////////////////////
        // Tooltips (Mouse)
        var tooltip = d3.select("body").append("div")
            .attr("class", "tooltip");

        bar.on("mouseover", function(d) {
            tooltip.html(d['value'])
                .style("visibility", "visible");
        })
            .on("mousemove", function(d) {
                tooltip.style("top", event.pageY - (tooltip[0][0].clientHeight + 5) + "px")
                    .style("left", event.pageX - (tooltip[0][0].clientWidth / 2.0) + "px");
            })
            .on("mouseout", function(d) {
                tooltip.style("visibility", "hidden");
            });

    }
});