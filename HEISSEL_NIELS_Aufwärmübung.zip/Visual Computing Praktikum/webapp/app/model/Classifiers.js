Ext.define('D2Cat.model.Classifiers', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'languages'],

    proxy: {
        type: 'ajax',
        url: './d2cat',
        extraParams: {cmd: 'classifierlist'},
        reader: {
            type: 'json',
            root: 'response'
        }
    }
});