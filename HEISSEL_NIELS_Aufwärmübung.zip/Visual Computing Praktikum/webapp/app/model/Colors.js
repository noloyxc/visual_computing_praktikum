Ext.define('D2Cat.model.Colors', {
    extend: 'Ext.data.Model',
    fields: ['name', 'color'],

    proxy: {
        type: 'ajax',
        url: './d2cat',
        extraParams: {cmd: 'colorlist'},
        reader: {
            type: 'json',
            root: 'response'
        }
    }
});