Ext.define('D2Cat.store.Colors', {
    extend: 'Ext.data.Store',
    requires: 'D2Cat.model.Colors',
    model: 'D2Cat.model.Colors'
});