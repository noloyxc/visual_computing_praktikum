Ext.define('D2Cat.store.Lexica', {
    extend: 'Ext.data.ArrayStore',
    fields: [
        'id', 'name'
    ]
});