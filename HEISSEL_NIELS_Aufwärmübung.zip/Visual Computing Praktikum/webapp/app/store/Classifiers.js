Ext.define('D2Cat.store.Classifiers', {
    extend: 'Ext.data.Store',
    requires: 'D2Cat.model.Classifiers',
    model: 'D2Cat.model.Classifiers'
});