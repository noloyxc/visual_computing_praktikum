Ext.define('D2Cat.store.Languages', {
    extend: 'Ext.data.ArrayStore',
    fields: [
        'id'
    ]
});