Ext.application({
    name: 'D2Cat',
    // Causes view/Viewport to be initialized
    autoCreateViewport: true,
    
    // Register Models
    models: ['Classifiers', 'Colors'],
    // Controllers listed here will automatically by initialized
    controllers: ['Classification', 'D2CatOnline']
});